package com.cognizant.estockmarketcommand.exception;

public class CompanyAlreadyExistsException extends RuntimeException{

}
