package com.cognizant.estockmarketquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstockmarketQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
